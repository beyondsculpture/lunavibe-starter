# Docs & Links

- Blitzy platform overview: https://blitzy.com/  
- Blitzy platform launch (news): https://www.devopsdigest.com/blitzy-platform-released  
- Blitzy platform capabilities (DBTA): https://www.dbta.com/Editorial/News-Flashes/Blitzy-Platform-Radically-Accelerates-Software-Development-with-AI-Powered-Autonomous-Batch-Building-167451.aspx

- Cloud Source Repositories restricted to prior customers (Jun 17, 2024): https://cloud.google.com/source-repositories/docs/release-notes  
- Secure Source Manager (SSM) overview: https://cloud.google.com/secure-source-manager/docs/overview  
- SSM: Connect to Cloud Build via triggers file: https://cloud.google.com/secure-source-manager/docs/connect-cloud-build
