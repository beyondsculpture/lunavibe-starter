# Project Guide — Lunavibe AI VID.GEN (for Blitzy)

## Goal
Ship a viral AI video generator using **Vertex AI** (Imagen 4, Gemini 2.5 Flash Image, Veo 3), **Cloud Run**, **Cloud Build/Deploy**, **GCS**, **Firestore**, **Cloud Logging/Monitoring**, with **Flutter** clients (web/iOS/Android).

## Hard constraints
- **Google-only runtime stack** on GCP; use **Secure Source Manager** (SSM) for git.
- Low-latency inference; prefer *fast* model variants for previews.
- **Skip‑Wait: Custom 4 Endings** UX path required.
- Video lengths: **5/8/10s**; 5s via trim of 6s; 10s via 8s + 2s hold.
- Resolutions: **480p/720p/1080p**.
- Storage on GCS; signed URLs for download/share.

## Architecture
Flutter client → Cloud Run API → Vertex (Imagen 4, Gemini 2.5 Flash Image, Veo 3) → GCS/Firestore. CI/CD via Cloud Build; deploy to Cloud Run.

## Repos & directories
- `backend/` FastAPI service (already scaffolded).
- `flutter/` console UI (skeleton).
- `deploy/` Cloud Deploy manifests.
- `blitzy/` this folder.
